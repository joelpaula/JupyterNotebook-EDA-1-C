# Emparelhamentos de delimitadores | Delimiter pairing
-------------------------------------------------------------
>**Unidade curricular | Course Unit** Estrutura de Dados e Algoritmos | Data Structures and Algorithms
>
>Curso|Course LCD-PL | Ano letivo|Year 2019/2020
>
>**Autor|Author** Joel Paula - nº 93393
>
>**Professor** Luis Ramada Pereira
>
>
>28-03-2020

This work is an exercise for checking the balance of parentheses (or other delimiters) in an expresison, using a Stack structure.

The Exercise is given here: [Trabalho-1-C.pdf](Trabalho-1-C.pdf)

To check the results, have a look at the [Jupyter Notebook](Trabalho-1-C-93392-JoelFilipeRodriguesPaula.ipynb)



